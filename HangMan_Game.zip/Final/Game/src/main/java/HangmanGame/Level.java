
package HangmanGame;
class Level {
    Level()
    {
       
    }
}
